package com.wanderlanka.user;

public enum UserRole {
    TOURIST,
    RIDER,
    HOTEL
}
