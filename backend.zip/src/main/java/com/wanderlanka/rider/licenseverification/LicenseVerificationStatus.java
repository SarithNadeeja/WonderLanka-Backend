package com.wanderlanka.rider.licenseverification;

public enum LicenseVerificationStatus {
    NOT_SUBMITTED,
    PENDING,
    APPROVED,
    REJECTED
}
