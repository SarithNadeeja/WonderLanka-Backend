package com.wanderlanka.rider.licenseverification;

public enum LicenseFileSide {
    FRONT,
    BACK
}
