package com.wanderlanka.rider.insuranceverification;

public enum InsuranceFileSide {
    FRONT,
    BACK
}
