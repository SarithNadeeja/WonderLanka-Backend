package com.wanderlanka.rider.insuranceverification;

public enum InsuranceVerificationStatus {
    NOT_SUBMITTED,
    PENDING,
    APPROVED,
    REJECTED
}
